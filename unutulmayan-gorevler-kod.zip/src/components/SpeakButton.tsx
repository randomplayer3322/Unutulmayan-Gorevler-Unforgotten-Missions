import { useEffect, useState } from "react";
import { Square, Volume2 } from "lucide-react";
import { speechLang, useI18n } from "@/i18n/lang";

function pickVoice(lang: string) {
  const voices = window.speechSynthesis?.getVoices?.() ?? [];
  const female = /yelda|filiz|emel|ayşe|ayse|sedef|zehra|sena|zira|female|woman|kadın|elsa|sara|helena|paulina|marisol|google/i;
  const male = /ahmet|tolga|male|erkek|david|mark|stefan/i;
  const same = voices.filter((voice) => voice.lang.toLowerCase().startsWith(lang));
  const pool = same.length ? same : voices;
  return [...pool].sort((a, b) => {
    const score = (voice: SpeechSynthesisVoice) =>
      (female.test(voice.name) ? 3 : 0) - (male.test(voice.name) ? 2 : 0);
    return score(b) - score(a);
  })[0];
}

export function SpeakButton({ text }: { text: string }) {
  const [on, setOn] = useState(false);
  const { lang, t } = useI18n();
  const spoken = t(text);

  useEffect(() => {
    const fill = () => pickVoice(speechLang(lang).slice(0, 2));
    window.speechSynthesis?.addEventListener?.("voiceschanged", fill);
    return () => {
      window.speechSynthesis?.removeEventListener?.("voiceschanged", fill);
      if (on) window.speechSynthesis?.cancel();
    };
  }, [on, lang]);

  function toggle() {
    const synth = window.speechSynthesis;
    if (!synth || !spoken.trim()) return;
    if (on) {
      synth.cancel();
      setOn(false);
      return;
    }
    synth.cancel();
    const utter = new SpeechSynthesisUtterance(spoken);
    utter.lang = speechLang(lang);
    utter.rate = 0.92;
    utter.pitch = lang === "tr" ? 1.22 : 1.05;
    const voice = pickVoice(speechLang(lang).slice(0, 2));
    if (voice) utter.voice = voice;
    utter.onend = () => setOn(false);
    utter.onerror = () => setOn(false);
    setOn(true);
    synth.speak(utter);
  }

  return (
    <button
      type="button"
      aria-label={on ? t("Okumayı durdur") : t("Hoparlörle dinle")}
      onClick={(event) => {
        event.stopPropagation();
        toggle();
      }}
      className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-line bg-bg text-fg"
    >
      {on ? <Square size={14} aria-hidden /> : <Volume2 size={16} aria-hidden />}
    </button>
  );
}
